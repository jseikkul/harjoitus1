# This is a simple demo README.md

Github Pages should use this as the entry point with default configs

![build](https://github.com/t-mu/simple-todo/actions/workflows/build.yml/badge.svg)
![e2e](https://github.com/t-mu/simple-todo/actions/workflows/e2e.yml/badge.svg)
![deployment](https://github.com/t-mu/simple-todo/actions/workflows/deployment.yml/badge.svg)